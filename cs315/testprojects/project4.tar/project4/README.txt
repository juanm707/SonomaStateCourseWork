/*
  Author: Juan Martinez
  Course: CS 315
  Assignment: Project 4
  File: README.txt
*/

FEATURES THAT WORK:

	 User must have the following files in directory (already included in this directory): albums.json, tracks.json, artists.json
along with each corresponding HTML template. If user does not have one or more file from these, it will result in error and exit. User then
"make" and can run "make run" or "./jsonToHTML.x" to run program. If successful, 3 files will be created: artists.html, albums.html, and tracks.html.
User can then open the 3 files in a browser to view the contents. Each file displays the entities, ordered list, and below each entity is info
about them.

FEATURES THAT DO NOT WORK:

	 I was not able to add accent marks, or any unicode characters. I was unsure on how to go about that.

POSSIBLE BUGS:

	 No unicode characters.



