/*
  Author: Juan Martinez
  Course: CS 315
  Assignment: Lab 5
  File: README.txt
*/

WHAT WORKS:

     Implemented constructor, insert, remove, lookup, and print. Constructor make space for the range of elements, in this case 5000.
All other functions work as expected. Created a program using the 3 files provided. First it adds all the numbers from valuesToInsert.txt
and then counts how many times memberValues.txt values are actually in the list. Also counts how many from nonMemberValues.txt that are not in list. At the end, it outputs the counts. Just use "make" and then "make run" or "./invertedListApp.x".

WHAT DOES NOT WORK:

     N/A

POSSIBLE BUGS:

     N/A

 
