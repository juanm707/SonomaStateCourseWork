/*
  Author: Juan Martinez
  Course: CS 315
  Assignment: Lab 3 Part B and C
*/

WHAT WORKS: Functions on dontTest.txt passed and output was 'OK'. remove should be working, fixed a
bug that when removing root, it didnt remove the inorder successor so it would have duplicates, but it works
properly now.

WHAT DOESNT WORK: That I know of all functions work.
      
