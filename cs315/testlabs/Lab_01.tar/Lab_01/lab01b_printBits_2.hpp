////////////////////////////////////////
// Author:     Dr. Kooshesh           //
// Student:    Juan Martinez          //
// Term:       Fall 2017              //
// Course:     CS 315                 //
// Assignment: Lab 01                 //
// Date:       9/11/17                //
// Professor:  Dr. Kooshesh           //
// File:       lab01b_printBits_2.hpp //
////////////////////////////////////////

typedef unsigned long bit_t;

void dumpBits0(bit_t v, int digitsPrinted=0);
void dumpBits(bit_t v);
