#include "TieBreakerScore.hpp"

TieBreakerScore::TieBreakerScore( Player *p1, Player *p2 ): Score(p1, p2) {}
