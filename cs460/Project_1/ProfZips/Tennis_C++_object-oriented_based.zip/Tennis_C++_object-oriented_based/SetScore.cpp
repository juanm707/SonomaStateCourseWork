#include<iostream>
#include "SetScore.hpp"

SetScore::SetScore( Player *p1, Player *p2 ): Score(p1, p2), tieScore(0) {}
  
bool SetScore::haveAWinner()           { return false;  }
bool SetScore::shouldPlayATieBreaker() { return false;  }

void SetScore::addTieScore( TieBreakerScore *score ) {
    addScore( score->getWinner() );
    this->tieScore = score;
}

void SetScore::print() {
    std::cout << "SetScore...   printing begins" << std::endl;
    std::cout << "p1 score = " << player1Score() << "\np2 Score = " << player2Score() << std::endl;
    if( tieScore != NULL )
      tieScore->print();
    std::cout << "SetScore...   printing ends" << std::endl;
}
