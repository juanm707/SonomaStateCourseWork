size = 20 * 10 - 81
div = 4 // 2 // 2
test1 = 3 * 2 + 5
test2 = (3 * 2) + 5
width = size * 5 - (3 + 2 * 5) + 2
a = 10 * 5 / 15
b = size < width
c = b < 0
d = b <> c
e = b == c == 1
print width
f = b > c
g = b >= c
h = b < c
i = b <= c
print a
z = 123456
print z
w = 0
forCheck = 0

for j in range(2):
    for t in range(2):
        for l in range(2):
            forCheck = forCheck + 1


s = 8
print forCheck

