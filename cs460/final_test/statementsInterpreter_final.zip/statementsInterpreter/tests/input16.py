c = 2
d = 3
v1 = []
v2 = [1, 3, 5,7,9]
v3 = [1 + 2, c + d, 5 - 3 * 2, 7, d + 9]
v4 = ["Data Structures", "Programming Languages", "Operating Systems"]


b = [4, 5, 6]
a = 3 + 2
b[-3] = 5 + 5
b[1] = b[-2] + 10
z = b[0] + b[1] + b[2]
# b[2] = [9,9,9] 
y = v4[d - c] + " and " + v4[d - 3]
print y
