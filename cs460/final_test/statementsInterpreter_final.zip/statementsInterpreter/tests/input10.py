a = 1



if (a):


    print "A is True"

elif a == 2:




    print "A is 2"

elif a == 3:
    print "A is 3"
elif a == 4:

    print "A is 4"

elif a == 5:



    print "A is 5"

b = 5
