a = 1
if (a):
    print "A is True"
else:
    print "A is False"
print "ABC123"
