grep -r $1 texts | wc -l
