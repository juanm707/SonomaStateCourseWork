chmod 711 vehicles
chmod 766 vehicles/public*
chmod 711 vehicles/?[!u]*
