mkdir -p vehicles/public_bicycles
mkdir vehicles/public_cars
mkdir vehicles/public_planes
mkdir vehicles/bicycles
mkdir vehicles/cars
mkdir vehicles/planes
