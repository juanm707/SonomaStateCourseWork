ls -l vehicles/public*/
mv -f vehicles/public_cars/* vehicles/cars/ 2> /dev/null
mv -f vehicles/public_planes/* vehicles/planes/ 2> /dev/null
mv -f vehicles/public_bicycles/* vehicles/bicycles/ 2> /dev/null
